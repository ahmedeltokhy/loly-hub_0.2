$(document).ready(function () {
   
    $('#product-gallery li').click(function () {
        $(this).addClass('active').siblings('li').removeClass('active')
        var src = $(this).children('img').attr('src')
        $('#product-gallery .big-image').removeClass('active').children('img').attr('src', src)
        setTimeout(function () {
            $('#product-gallery .big-image').addClass('active');
        }.bind(this), 300); //Here delay in milliseconds
    })

    $('body').on('click', '.lp-countEx .bttn', function () {
        
        var currentValue = parseInt($(this).siblings('input').val());
        var plus = 1;
        if (currentValue > 100) {
            plus = 10;
        }
        if ($(this).hasClass('plus')) {
            $(this).siblings('input').val(currentValue + plus)
        }
        else {
            $(this).siblings('input').val(currentValue - plus)
        }
        get_card_lp_count()
        get_lp_count()
        var eval = $(this).siblings('input').val()
        if (eval <= 0 || isNaN(eval) || eval <= " ") { $(this).siblings('input').val(0) }
    })

    $('body').on('click', '.lp-count .bttn', function () {
        var currentValue = parseInt($(this).siblings('input').val());
        var spt_hdthis = $(this).siblings('input:hidden').attr('id').substring(6);

        var initialvalue = document.getElementById("hiddeninput" + spt_hdthis).value;
        var plus = 1;
        if (currentValue > 100) {
            plus = 50;
        }
        var cal = 0;
        if ($(this).hasClass('plus')) {
            cal = currentValue + plus
            if (cal <= initialvalue) {
                $(this).siblings('input:text').val(currentValue + plus)
                get_lp_count();
            }
            //$("#h41").data("value", cal);
            //alert($("#h41").attr["data-value"]);
        }
        else {
            cal = currentValue - plus
            if (cal <= initialvalue) {
                $(this).siblings('input:text').val(currentValue - plus)
                get_lp_count();
            }
            //$("#h41").data("value", cal);
            ////alert($("#h41").attr["data-value"]);

        }

        if (cal <= initialvalue) {
            document.getElementById("para" + spt_hdthis).innerHTML = "LP " + cal;
            document.getElementById("h4" + spt_hdthis).innerHTML = cal;
            var hdRateValue = document.getElementById("hidden" + spt_hdthis).value;
            var h3value = 0;
            h3value = cal / hdRateValue;
            document.getElementById("h3" + spt_hdthis).innerHTML = h3value;

        }
        else
            alert("value should not  be exceed ")
    })
    $('#show-select-redeemable').click(function () {
        $('#select-redeemable').slideDown(600)
    })
    ncount = 0;
    $('#select-redeemable .item').click(function () {
        var imgSrc = $(this).find('img').attr('src');
        var inputpointsrates = $(this).find('input[type=hidden]').val(); /*1200$0.1*/
        var vals = inputpointsrates.split("$");
        //split the inputpointsrates syed
        var points = vals[0];
        var rates = vals[1];
        var hdnprogramid = vals[2];
        var username = vals[3];
        var calcpointsrate = 0;
        var calcpointsrate1 = 0;
        calcpointsrate = points * rates;
        //  calcpointsrate.toFixed(2);
        var itemId = $(this).attr('data-id');

        $(this).toggleClass('active');
        $('#checkout-lp').slideDown('slow')
        if ($(this).hasClass('active')) {
            //alert(ncount)
            ncount++;
            $('#checkout-lp table').append(`<tr data-id="` + itemId + `">
        <td><img src="`+ imgSrc + `" alt=""></td>
        <td><h3 id=h3`+ ncount + `> ` + points + ` </h3><p id=para` + ncount + `>LP ` + calcpointsrate + `</p></td>
        <td>
          <div class="lp-count">
            <div class ="bttn plus"><i class ="fa fa-plus"></i></div>
            <input class="points2Redeem" id=input`+ ncount + ` type="text"  value=` + calcpointsrate1 + ` >
            <input id=hidden`+ ncount + ` type="hidden" value= ` + rates + ` >
            <input id=hiddeninput`+ ncount + ` type="hidden"  value= ` + calcpointsrate + ` >
             <input class ="programIDval" id=hiddenpid`+ ncount + ` type="hidden" value= ` + hdnprogramid + ` >
             <input class ="ProgramUserName" id=hiddenuserName`+ ncount + ` type="hidden" value= ` + username + ` >
      <div class="bttn minus"><i class="fa fa-minus"></i></div>
          </div><!-- End .lp-count -->
        </td>
        <td>
          <h4 id=h4`+ ncount + ` > ` + calcpointsrate + ` </h4>
          <a href="#" class="remove"><i class="fa fa-times-circle-o"></i></a>
          <a href="#" class ="help"><i class ="fa fa-info-circle"></i></a>


        </td>
      </tr>`)

        }
        else {
            $('#checkout-lp tr[data-id=' + itemId + ']').remove()
        }
        get_lp_count()
        return false;
    })
    $('body').on('click', '#checkout-lp tr .remove', function () {
        var itemId = $(this).parents('tr').attr('data-id')

        $('#select-redeemable .item[data-id=' + itemId + ']').removeClass('active')
        $(this).parents('tr').fadeOut(5000).delay(800).remove()
        get_lp_count()
        return false;
    })
    // start main slider
    $('#da-slider').slick({
        dots: false,
        infinite: true,
        speed: 700,
        slidesToShow: 1,
        // easing: 'easeInOutSine',
        // prevArrow: $('#main-slider-navs .prev') ,
        // nextArrow: $('#main-slider-navs .next')

    });
    // end main slider
    $('#show-select-redeemable').click(function () {
        $('html,body').animate({
            scrollTop: $("#select-redeemable").offset().top
        },
            'slow');
    })
    $('body').on('keydown', '.lp-count input', function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
            // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    })
    $('body').on('keyup', '.lp-count input', function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        get_lp_count()

    })
    function get_lp_count() {
        var arrNumber = new Array();
        $('#checkout-lp table tr  input:text').each(function () {
            arrNumber.push($(this).val());
        })
        var result = arrNumber.map(function (x) {
            return parseInt(x, 10);
        });
        var total = 0;
        for (var i = 0; i < arrNumber.length; i++) {
            total += arrNumber[i] << 0;
        }
        if (total > 0)
            $('#checkout-lp .lp-num b').text(total)
        else
            $('#checkout-lp .lp-num b').text('')
    }

    function get_card_lp_count() {
        var arrNumber = new Array();
        $('.card-items .item  input').each(function () {
            var price = $(this).parents('.item').find('.price-lp h4').text()
            arrNumber.push($(this).val() * price);
        })
        var result = arrNumber.map(function (x) {
            return parseInt(x, 10);
        });
        var totalLp = 0;
        for (var i = 0; i < arrNumber.length; i++) {
            totalLp += arrNumber[i] << 0;

        }
        $('.total-count-items .number').text(totalLp)
        $('.total .number').text("Total : " + totalLp)


    }
    $('.card-items .remove-item,.history-day .item .remove-item').click(function () {
        $(this).parents('.item').remove()
        get_card_lp_count()
        return false;
    })
    $('.history-day .item .remove-item a').click(function () {
        $(this).parents('.col-sm-6.col-md-4').remove()
        return false;
    })
    get_card_lp_count()
    get_date_redeemed()
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });



});

/*AAA Modification*/
function deleteAllCookies() {
    var cookies = document.cookie.split(";");

    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        var eqPos = cookie.indexOf("=");
        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
    }
   
    $.ajax({
        type: "POST",
        url: "Login.aspx/deleteSession",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: OnSuccess,
        failure: function (response) {
            alert(response.d);
        }
    });
    function OnSuccess(response) {
        alert(response.d);
    }
    window.location.reload();
}

//window.onunload = function () {
//    $.ajax({
//        type: "POST",
//        url: "logout.aspx",
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: OnSuccess,
//        failure: function (response) {
//            alert(response.d);
//        }
//    });
//    function OnSuccess(response) {
//        log(response.d);
//    }

//};

//window.onbeforeunload = function () {
//    $.ajax({
//        type: "POST",
//        url: "logout.aspx",
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: OnSuccess,
//        failure: function (response) {
//            alert(response.d);
//        }
//    });
//    function OnSuccess(response) {
//        log(response.d);
//    }

//};
/*****************************/

function get_date_redeemed() {
    $('.history-day').each(function () {
        if ($(window).scrollTop() + 50 >= $(this).offset().top) {
            $('#wishlist .title span').text('(' + $(this).attr('data-date') + ')'); //or any other way you want to get the date
            $('#wishlist .total-all').text($(this).attr('data-total-redeemed') + ' LP'); //or any other way you want to get the date
            return; //break the loop
        }
    });
}
$(window).load(function () {
   
    $(function () {
        $('a.remove').click(function (e) {
            var cfrm = confirm("are you sure you want to delete the program?");
           if(!cfrm) e.preventDefault();
        });

        $(window).on("scroll resize load", function () {
            get_date_redeemed()
        });

        $(document).ready(function () {
           // alert("url");
            history.replaceState(null, null, "/");
           
            $(window).trigger('scroll'); // init the value
        });

    })
})
